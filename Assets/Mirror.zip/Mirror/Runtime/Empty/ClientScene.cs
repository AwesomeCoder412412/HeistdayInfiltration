// moved into NetworkClient on 2021-03-07
