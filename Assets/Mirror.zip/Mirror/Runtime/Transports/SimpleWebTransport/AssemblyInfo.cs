using System.Reflection;
using System.Runtime.CompilerServices;

[assembly: AssemblyVersion("1.3.0")]

[assembly: InternalsVisibleTo("SimpleWebTransport.Tests.Runtime")]
[assembly: InternalsVisibleTo("SimpleWebTransport.Tests.Editor")]
